import { PowOfPipe } from './pow-of.pipe';

describe('PowOfPipe', () => {
  it('create an instance', () => {
    const pipe = new PowOfPipe();
    expect(pipe).toBeTruthy();
  });
});
